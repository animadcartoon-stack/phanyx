const statusEl = document.getElementById("status");
const buttons = [...document.querySelectorAll("[data-action]")];

function setBusy(value, message = "") {
  buttons.forEach((button) => (button.disabled = value));
  statusEl.className = "status";
  statusEl.textContent = message;
}

function setMessage(message, error = false) {
  buttons.forEach((button) => (button.disabled = false));
  statusEl.className = error ? "status error" : "status";
  statusEl.textContent = message;
}

function isProtectedUrl(url = "") {
  return /^(chrome|edge|brave|opera|about|view-source|devtools|chrome-extension):/i.test(url);
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("Nenhuma aba ativa encontrada.");
  return tab;
}

async function ensureCapturablePage(tab) {
  if (isProtectedUrl(tab.url || "")) {
    throw new Error("Volte para a página que deseja capturar. Esta aba é uma página interna do navegador/PHANYX Print.");
  }
}

async function captureVisible(tab) {
  await ensureCapturablePage(tab);
  setBusy(true, "Capturando área visível…");
  const response = await chrome.runtime.sendMessage({
    type: "PHANYX_CAPTURE_VISIBLE",
    tabId: tab.id,
    windowId: tab.windowId
  });
  if (!response?.ok) throw new Error(response?.error || "Falha ao capturar.");
  window.close();
}

async function startSelection(tab) {
  await ensureCapturablePage(tab);
  setBusy(true, "Ativando seleção longa…");
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["selection.js"]
  });
  window.close();
}

async function captureFullPage(tab) {
  await ensureCapturablePage(tab);
  setBusy(true, "Capturando página inteira…");
  const response = await chrome.runtime.sendMessage({
    type: "PHANYX_CAPTURE_FULL_PAGE",
    tabId: tab.id,
    windowId: tab.windowId
  });
  if (!response?.ok) throw new Error(response?.error || "Falha ao capturar a página inteira.");
  window.close();
}

buttons.forEach((button) => {
  button.addEventListener("click", async () => {
    try {
      const tab = await getActiveTab();
      const action = button.dataset.action;

      if (action === "selection") await startSelection(tab);
      if (action === "visible") await captureVisible(tab);
      if (action === "full") await captureFullPage(tab);
    } catch (error) {
      setMessage(error?.message || String(error), true);
    }
  });
});

(async () => {
  try {
    const tab = await getActiveTab();
    if (isProtectedUrl(tab.url || "")) {
      buttons.forEach((button) => (button.disabled = true));
      setMessage("Volte para a página que deseja capturar para usar o PHANYX Print.");
    }
  } catch {}
})();
