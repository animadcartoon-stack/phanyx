const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const selectionSessions = new Map();

function getSelectionSession(sessionId) {
  const session = selectionSessions.get(sessionId);
  if (!session) {
    throw new Error("Sessão de seleção não encontrada.");
  }
  return session;
}

async function startSelectionSession(sessionId, tab) {
  selectionSessions.set(sessionId, {
    tabId: tab.id,
    windowId: tab.windowId,
    title: tab.title || "captura",
    parts: [],
    lastCaptureAt: 0,
    viewportWidth: null,
    viewportHeight: null
  });
}

async function captureSelectionSessionFrame(sessionId, tab, force = false) {
  const session = getSelectionSession(sessionId);

  if (session.tabId !== tab.id || session.windowId !== tab.windowId) {
    throw new Error("A sessão de seleção pertence a outra aba.");
  }

  const metrics = await getMetrics(tab.id);
  const last = session.parts[session.parts.length - 1];

  if (
    last &&
    Math.abs(last.scrollX - metrics.scrollX) < 2 &&
    Math.abs(last.scrollY - metrics.scrollY) < 2
  ) {
    return {
      added: false,
      scrollX: metrics.scrollX,
      scrollY: metrics.scrollY
    };
  }

  const elapsed = Date.now() - session.lastCaptureAt;
  const minimumGap = 540;

  if (session.lastCaptureAt && elapsed < minimumGap) {
    await wait(minimumGap - elapsed);
  }

  const freshMetrics = await getMetrics(tab.id);
  const dataUrl = await captureVisible(tab.windowId);
  session.lastCaptureAt = Date.now();

  session.viewportWidth ??= freshMetrics.viewportWidth;
  session.viewportHeight ??= freshMetrics.viewportHeight;
  session.title = freshMetrics.title || session.title;

  session.parts.push({
    dataUrl,
    scrollX: freshMetrics.scrollX,
    scrollY: freshMetrics.scrollY,
    viewportWidth: freshMetrics.viewportWidth,
    viewportHeight: freshMetrics.viewportHeight
  });

  return {
    added: true,
    scrollX: freshMetrics.scrollX,
    scrollY: freshMetrics.scrollY
  };
}

async function finishSelectionSession(sessionId, rect) {
  const session = getSelectionSession(sessionId);

  if (!session.parts.length) {
    throw new Error("Nenhum trecho foi capturado durante a seleção.");
  }

  await storeCapture({
    type: "selection-live",
    title: session.title,
    rect,
    viewportWidth: session.viewportWidth,
    viewportHeight: session.viewportHeight,
    parts: session.parts
  });

  selectionSessions.delete(sessionId);
  await openPreview();
}


function friendlyError(error) {
  const message = error?.message || String(error || "Erro desconhecido.");
  if (/Cannot access|Missing host permission|chrome:\/\//i.test(message)) {
    return "Esta página é protegida pelo navegador e não permite injeção de scripts. Abra um site comum e tente novamente.";
  }
  return message;
}

async function storeCapture(payload) {
  await chrome.storage.local.set({
    phanyxPrintCapture: {
      ...payload,
      createdAt: Date.now()
    }
  });
}

async function openPreview() {
  await chrome.tabs.create({ url: chrome.runtime.getURL("preview.html") });
}

async function captureVisible(windowId) {
  return chrome.tabs.captureVisibleTab(windowId, { format: "png" });
}

async function getMetrics(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => ({
      scrollX: window.scrollX,
      scrollY: window.scrollY,
      scrollWidth: Math.max(
        document.documentElement.scrollWidth,
        document.body?.scrollWidth || 0
      ),
      scrollHeight: Math.max(
        document.documentElement.scrollHeight,
        document.body?.scrollHeight || 0
      ),
      viewportHeight: window.innerHeight,
      viewportWidth: window.innerWidth,
      title: document.title || "pagina"
    })
  });
  return result;
}

async function prepareFixedElements(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const changed = [];

      for (const el of document.querySelectorAll("body *")) {
        const cs = getComputedStyle(el);

        if (cs.position === "fixed" || cs.position === "sticky") {
          changed.push({
            el,
            visibility: el.style.visibility,
            transition: el.style.transition
          });
        }
      }

      window.__PHANYX_PRINT_FIXED__ = changed;

      return {
        scrollX: window.scrollX,
        scrollY: window.scrollY,
        scrollWidth: Math.max(
          document.documentElement.scrollWidth,
          document.body?.scrollWidth || 0
        ),
        scrollHeight: Math.max(
          document.documentElement.scrollHeight,
          document.body?.scrollHeight || 0
        ),
        viewportHeight: window.innerHeight,
        viewportWidth: window.innerWidth,
        title: document.title || "pagina"
      };
    }
  });

  return result;
}

async function setFixedVisibility(tabId, hidden) {
  await chrome.scripting.executeScript({
    target: { tabId },
    args: [hidden],
    func: (shouldHide) => {
      const changed = window.__PHANYX_PRINT_FIXED__ || [];

      for (const item of changed) {
        if (shouldHide) {
          item.el.style.transition = "none";
          item.el.style.visibility = "hidden";
        } else {
          item.el.style.visibility = item.visibility;
          item.el.style.transition = item.transition;
        }
      }
    }
  });
}

async function restorePage(tabId, x, y) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      args: [x, y],
      func: (scrollX, scrollY) => {
        const changed = window.__PHANYX_PRINT_FIXED__ || [];

        for (const item of changed) {
          item.el.style.visibility = item.visibility;
          item.el.style.transition = item.transition;
        }

        delete window.__PHANYX_PRINT_FIXED__;
        window.scrollTo(scrollX, scrollY);
      }
    });
  } catch {
    // A aba pode ter sido fechada ou navegado durante a captura.
  }
}

async function scrollToPosition(tabId, x, y) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    args: [x, y],
    func: (targetX, targetY) => {
      window.scrollTo(targetX, targetY);
      return {
        x: window.scrollX,
        y: window.scrollY,
        width: window.innerWidth,
        height: window.innerHeight
      };
    }
  });

  return result;
}

function buildAxisPositions(start, end, viewportSize, maxScroll) {
  if (end <= start) return [Math.max(0, Math.min(start, maxScroll))];

  let first = Math.max(0, Math.min(start, maxScroll));
  const positions = [first];

  let coveredEnd = first + viewportSize;

  while (coveredEnd < end) {
    let next = Math.min(coveredEnd, maxScroll);

    if (next <= positions[positions.length - 1]) break;

    positions.push(next);
    coveredEnd = next + viewportSize;
  }

  if (positions[positions.length - 1] + viewportSize < end && maxScroll > positions[positions.length - 1]) {
    positions.push(maxScroll);
  }

  return [...new Set(positions)];
}

async function captureWithThrottle(windowId, state) {
  const elapsed = Date.now() - state.lastCaptureAt;
  const minimumGap = 540;

  if (state.lastCaptureAt && elapsed < minimumGap) {
    await wait(minimumGap - elapsed);
  }

  const dataUrl = await captureVisible(windowId);
  state.lastCaptureAt = Date.now();
  return dataUrl;
}

async function runSelectionCapture(tabId, windowId, rect, restoreScroll) {
  let meta;

  try {
    meta = await prepareFixedElements(tabId);

    const maxScrollX = Math.max(0, meta.scrollWidth - meta.viewportWidth);
    const maxScrollY = Math.max(0, meta.scrollHeight - meta.viewportHeight);

    const rectRight = rect.left + rect.width;
    const rectBottom = rect.top + rect.height;

    const xPositions = buildAxisPositions(
      rect.left,
      rectRight,
      meta.viewportWidth,
      maxScrollX
    );

    const yPositions = buildAxisPositions(
      rect.top,
      rectBottom,
      meta.viewportHeight,
      maxScrollY
    );

    // Para seleção longa, elementos fixed/sticky são escondidos para não
    // aparecerem repetidos e para revelar o conteúdo que existe por baixo.
    await setFixedVisibility(tabId, true);
    await wait(120);

    const parts = [];
    const throttleState = { lastCaptureAt: 0 };

    for (const y of yPositions) {
      for (const x of xPositions) {
        const actual = await scrollToPosition(tabId, x, y);
        await wait(180);

        const dataUrl = await captureWithThrottle(windowId, throttleState);

        parts.push({
          dataUrl,
          scrollX: actual.x,
          scrollY: actual.y,
          viewportWidth: actual.width,
          viewportHeight: actual.height
        });
      }
    }

    await storeCapture({
      type: "selection-long",
      title: meta.title,
      rect,
      viewportWidth: meta.viewportWidth,
      viewportHeight: meta.viewportHeight,
      parts
    });

    await openPreview();
  } finally {
    const restoreX = restoreScroll?.x ?? meta?.scrollX ?? 0;
    const restoreY = restoreScroll?.y ?? meta?.scrollY ?? 0;

    if (meta) {
      await restorePage(tabId, restoreX, restoreY);
    }
  }
}

function buildScrollPositions(scrollHeight, viewportHeight) {
  const maxY = Math.max(0, scrollHeight - viewportHeight);
  const positions = [0];

  if (maxY === 0) return positions;

  for (let y = viewportHeight; y < maxY; y += viewportHeight) {
    positions.push(y);
  }

  if (positions[positions.length - 1] !== maxY) {
    positions.push(maxY);
  }

  return positions;
}

async function runFullPageCapture(tabId, windowId) {
  let meta;

  try {
    meta = await prepareFixedElements(tabId);

    await scrollToPosition(tabId, 0, 0);
    await wait(220);

    const positions = buildScrollPositions(meta.scrollHeight, meta.viewportHeight);
    const parts = [];
    const throttleState = { lastCaptureAt: 0 };

    for (let i = 0; i < positions.length; i++) {
      const actual = await scrollToPosition(tabId, 0, positions[i]);
      await wait(180);

      // Mantém elementos fixos apenas no topo da página.
      if (i === 1) {
        await setFixedVisibility(tabId, true);
        await wait(80);
      }

      const dataUrl = await captureWithThrottle(windowId, throttleState);

      parts.push({
        dataUrl,
        scrollY: actual.y,
        viewportHeight: actual.height,
        viewportWidth: actual.width
      });
    }

    await storeCapture({
      type: "full",
      title: meta.title,
      scrollHeight: meta.scrollHeight,
      viewportHeight: meta.viewportHeight,
      viewportWidth: meta.viewportWidth,
      parts
    });

    await openPreview();
  } finally {
    if (meta) {
      await restorePage(tabId, meta.scrollX, meta.scrollY);
    }
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message?.type === "PHANYX_CAPTURE_VISIBLE") {
        const dataUrl = await captureVisible(message.windowId);

        let title = "captura";
        try {
          const metrics = await getMetrics(message.tabId);
          title = metrics.title;
        } catch {}

        await storeCapture({
          type: "visible",
          title,
          dataUrl
        });

        await openPreview();
        sendResponse({ ok: true });
        return;
      }


      if (message?.type === "PHANYX_SELECTION_SESSION_START") {
        const tab = sender.tab;

        if (!tab?.id || !tab?.windowId) {
          throw new Error("Não foi possível identificar a aba.");
        }

        await startSelectionSession(message.sessionId, tab);
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "PHANYX_SELECTION_SESSION_CAPTURE") {
        const tab = sender.tab;

        if (!tab?.id || !tab?.windowId) {
          throw new Error("Não foi possível identificar a aba.");
        }

        const result = await captureSelectionSessionFrame(
          message.sessionId,
          tab,
          Boolean(message.force)
        );

        sendResponse({ ok: true, ...result });
        return;
      }

      if (message?.type === "PHANYX_SELECTION_SESSION_FINISH") {
        await finishSelectionSession(message.sessionId, message.rect);
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "PHANYX_SELECTION_SESSION_CANCEL") {
        selectionSessions.delete(message.sessionId);
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "PHANYX_CAPTURE_SELECTION_LONG") {
        const tab = sender.tab;

        if (!tab?.id || !tab?.windowId) {
          throw new Error("Não foi possível identificar a aba.");
        }

        await runSelectionCapture(
          tab.id,
          tab.windowId,
          message.rect,
          message.restoreScroll
        );

        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "PHANYX_CAPTURE_FULL_PAGE") {
        await runFullPageCapture(message.tabId, message.windowId);
        sendResponse({ ok: true });
        return;
      }

      sendResponse({ ok: false, error: "Comando desconhecido." });
    } catch (error) {
      console.error("PHANYX Print:", error);
      sendResponse({ ok: false, error: friendlyError(error) });
    }
  })();

  return true;
});
