# PHANYX Print v0.1.5

Extensão para Chrome, Edge, Brave e outros navegadores Chromium.

## Recursos desta versão

- Selecionar uma área clicando e arrastando.
- Capturar a área visível.
- Capturar a página inteira verticalmente.
- Pré-visualizar antes de salvar.
- Copiar a captura para a área de transferência.
- Salvar em PNG.
- Salvar em JPG.
- Restaura a posição da página depois da captura inteira.
- Evita repetir elementos `fixed`/`sticky` nas capturas seguintes.
- Processamento local: a extensão não envia imagens para servidores.

## Como instalar no Google Chrome

1. Descompacte o ZIP.
2. Abra `chrome://extensions`.
3. Ative **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação**.
5. Escolha a pasta `PHANYX-Print-v0.1.0`.
6. Fixe **PHANYX Print** na barra do navegador.

## Como instalar no Microsoft Edge

1. Descompacte o ZIP.
2. Abra `edge://extensions`.
3. Ative **Modo de desenvolvedor**.
4. Clique em **Carregar descompactado**.
5. Escolha a pasta `PHANYX-Print-v0.1.0`.

## Observações

- Páginas internas do navegador (`chrome://`, `edge://`) podem impedir injeção de scripts.
- O Chrome limita `captureVisibleTab()` a duas chamadas por segundo; a captura de página inteira respeita esse limite.
- Nesta versão inicial, imagens resultantes acima de 30.000 px de altura são bloqueadas para evitar falhas de memória do canvas.
- Sites com animações, vídeos ou conteúdo que muda enquanto a página rola podem produzir pequenas diferenças entre os segmentos.

## Próximas versões sugeridas

- Seleção com rolagem automática ao arrastar até a borda.
- Recorte e edição na prévia.
- Setas, retângulos, texto, marca-texto e desfoque.
- Salvar em PDF.
- Captura de elemento específico.
- Histórico local de capturas.
- Atalhos de teclado.
- Versão Firefox.


## v0.1.1

- Identidade visual atualizada com o ícone oficial fornecido para o PHANYX Print.


## v0.1.2

- Seleção por arraste agora continua além da área visível.
- Rolagem automática vertical e horizontal ao aproximar o ponteiro das bordas.
- Captura longa selecionada é dividida em vários trechos e remontada na prévia.
- A posição original da página é restaurada após a captura.
- Elementos `fixed` e `sticky` são ocultados durante a seleção longa para evitar repetições.


## v0.1.3

- Rolagem automática da seleção longa reforçada com loop contínuo.
- A seleção é recalculada durante eventos de rolagem, mesmo sem novos eventos de movimento do mouse.
- Área de ativação da rolagem vertical aumentada para facilitar chegar ao fim de páginas longas.
- Mensagem orientativa exibida durante o arraste.
- O popup agora reconhece páginas internas/protegidas e orienta o usuário em vez de exibir erro técnico de permissão.


## Navegadores compatíveis

Esta edição usa Manifest V3 e foi preparada para navegadores baseados em Chromium:

- Google Chrome
- Brave
- Opera
- Vivaldi
- Microsoft Edge
- Outros navegadores Chromium compatíveis com extensões Manifest V3

O Edge já possui um recurso nativo semelhante, mas o PHANYX Print também pode ser usado nele.

Uma edição específica para Firefox será preparada separadamente para garantir compatibilidade e publicação adequada.

## v0.1.4

- A captura é copiada automaticamente para a área de transferência ao abrir a prévia.
- O botão **Copiar** continua disponível para copiar novamente quando necessário.
- Corrigida a sobreposição dos segmentos na captura de página inteira.
- A composição agora recorta a faixa já capturada quando o último scroll é menor que uma tela completa.
- Identidade PHANYX preservada e processamento continua local no navegador.


## v0.1.5

- A opção **Selecionar área** não faz mais uma segunda varredura depois que o mouse é solto.
- Os trechos necessários são capturados durante o próprio arraste e a rolagem automática.
- Ao soltar o mouse, a extensão apenas monta, recorta e abre a prévia.
- A cópia automática para a área de transferência continua ativa.
- A rolagem é pausada brevemente somente no instante de registrar cada trecho, respeitando o limite do navegador.
