const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d", { alpha: false });
const stage = document.getElementById("stage");
const loading = document.getElementById("loading");
const meta = document.getElementById("meta");
const toast = document.getElementById("toast");

let capture = null;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => toast.classList.remove("show"), 1800);
}

function sanitizeName(value) {
  return String(value || "captura")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 90) || "captura";
}

function fileStamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Não foi possível carregar uma parte da captura."));
    img.src = src;
  });
}

function assertCanvasSize(width, height) {
  const MAX_DIMENSION = 30000;
  const MAX_AREA = 180_000_000;

  if (width > MAX_DIMENSION || height > MAX_DIMENSION || width * height > MAX_AREA) {
    throw new Error(
      `A captura ficou muito grande (${width} × ${height}px). ` +
      `Reduza a área ou use a captura de página inteira em partes menores.`
    );
  }
}

async function renderVisible(data) {
  const img = await loadImage(data.dataUrl);
  assertCanvasSize(img.naturalWidth, img.naturalHeight);

  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  ctx.drawImage(img, 0, 0);
}

async function renderSelectionLong(data) {
  if (!Array.isArray(data.parts) || !data.parts.length) {
    throw new Error("A seleção não contém partes capturadas.");
  }

  const first = await loadImage(data.parts[0].dataUrl);
  const firstPart = data.parts[0];

  const cssViewportWidth = Math.max(1, firstPart.viewportWidth || data.viewportWidth || first.naturalWidth);
  const cssViewportHeight = Math.max(1, firstPart.viewportHeight || data.viewportHeight || first.naturalHeight);

  const scaleX = first.naturalWidth / cssViewportWidth;
  const scaleY = first.naturalHeight / cssViewportHeight;

  const rect = data.rect;
  const outWidth = Math.max(1, Math.round(rect.width * scaleX));
  const outHeight = Math.max(1, Math.round(rect.height * scaleY));

  assertCanvasSize(outWidth, outHeight);

  canvas.width = outWidth;
  canvas.height = outHeight;

  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < data.parts.length; i++) {
    const part = data.parts[i];
    const img = i === 0 ? first : await loadImage(part.dataUrl);

    const vpW = part.viewportWidth || cssViewportWidth;
    const vpH = part.viewportHeight || cssViewportHeight;

    const viewLeft = part.scrollX;
    const viewTop = part.scrollY;
    const viewRight = viewLeft + vpW;
    const viewBottom = viewTop + vpH;

    const selLeft = rect.left;
    const selTop = rect.top;
    const selRight = rect.left + rect.width;
    const selBottom = rect.top + rect.height;

    const ix1 = Math.max(selLeft, viewLeft);
    const iy1 = Math.max(selTop, viewTop);
    const ix2 = Math.min(selRight, viewRight);
    const iy2 = Math.min(selBottom, viewBottom);

    if (ix2 <= ix1 || iy2 <= iy1) continue;

    const sx = Math.round((ix1 - viewLeft) * scaleX);
    const sy = Math.round((iy1 - viewTop) * scaleY);
    const sw = Math.max(1, Math.round((ix2 - ix1) * scaleX));
    const sh = Math.max(1, Math.round((iy2 - iy1) * scaleY));

    const dx = Math.round((ix1 - selLeft) * scaleX);
    const dy = Math.round((iy1 - selTop) * scaleY);
    const dw = sw;
    const dh = sh;

    ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
  }
}

async function renderFull(data) {
  if (!Array.isArray(data.parts) || !data.parts.length) {
    throw new Error("A captura da página inteira não contém partes.");
  }

  const first = await loadImage(data.parts[0].dataUrl);
  const scaleX = first.naturalWidth / Math.max(1, data.viewportWidth);
  const scaleY = first.naturalHeight / Math.max(1, data.viewportHeight);

  const targetWidth = first.naturalWidth;
  const targetHeight = Math.max(
    first.naturalHeight,
    Math.round(data.scrollHeight * scaleY)
  );

  assertCanvasSize(targetWidth, targetHeight);

  canvas.width = targetWidth;
  canvas.height = targetHeight;
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  let coveredUntilCssY = 0;

  for (let i = 0; i < data.parts.length; i++) {
    const part = data.parts[i];
    const img = i === 0 ? first : await loadImage(part.dataUrl);

    const viewportCssHeight = Number(part.viewportHeight || data.viewportHeight);
    const viewTop = Number(part.scrollY || 0);
    const viewBottom = Math.min(viewTop + viewportCssHeight, data.scrollHeight);

    const drawFromCssY = Math.max(viewTop, coveredUntilCssY);
    const drawableCssHeight = viewBottom - drawFromCssY;

    if (drawableCssHeight <= 0) continue;

    const cropTopCss = drawFromCssY - viewTop;
    const sy = Math.max(0, Math.round(cropTopCss * scaleY));
    const sh = Math.min(
      img.naturalHeight - sy,
      Math.max(1, Math.round(drawableCssHeight * scaleY))
    );

    const dy = Math.round(drawFromCssY * scaleY);

    ctx.drawImage(
      img,
      0,
      sy,
      img.naturalWidth,
      sh,
      0,
      dy,
      targetWidth,
      sh
    );

    coveredUntilCssY = Math.max(coveredUntilCssY, viewBottom);
  }
}

async function canvasBlob(type, quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => blob ? resolve(blob) : reject(new Error("Não foi possível gerar a imagem.")),
      type,
      quality
    );
  });
}

async function save(type) {
  let blob;
  let ext;

  if (type === "jpg") {
    const out = document.createElement("canvas");
    out.width = canvas.width;
    out.height = canvas.height;

    const outCtx = out.getContext("2d", { alpha: false });
    outCtx.fillStyle = "#ffffff";
    outCtx.fillRect(0, 0, out.width, out.height);
    outCtx.drawImage(canvas, 0, 0);

    blob = await new Promise((resolve, reject) => {
      out.toBlob(
        (b) => b ? resolve(b) : reject(new Error("Não foi possível gerar o JPG.")),
        "image/jpeg",
        0.94
      );
    });

    ext = "jpg";
  } else {
    blob = await canvasBlob("image/png");
    ext = "png";
  }

  const url = URL.createObjectURL(blob);
  const filename = `PHANYX-Print/${sanitizeName(capture?.title)}_${fileStamp()}.${ext}`;

  try {
    await chrome.downloads.download({
      url,
      filename,
      saveAs: true
    });

    showToast(`${ext.toUpperCase()} pronto para salvar`);
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
}

async function copyImage({ silent = false } = {}) {
  const blob = await canvasBlob("image/png");

  await navigator.clipboard.write([
    new ClipboardItem({ "image/png": blob })
  ]);

  if (!silent) {
    showToast("Imagem copiada");
  }
}

async function tryAutoCopy() {
  try {
    await copyImage({ silent: true });
    showToast("✓ Captura copiada automaticamente");
    return true;
  } catch (error) {
    console.warn("PHANYX Print: cópia automática não disponível.", error);
    showToast("Captura pronta • clique em Copiar se quiser enviar à área de transferência");
    return false;
  }
}

async function init() {
  try {
    const stored = await chrome.storage.local.get("phanyxPrintCapture");
    capture = stored.phanyxPrintCapture;

    if (!capture) {
      throw new Error("Nenhuma captura encontrada.");
    }

    if (capture.type === "selection-long" || capture.type === "selection-live") {
      await renderSelectionLong(capture);
    } else if (capture.type === "full") {
      await renderFull(capture);
    } else {
      await renderVisible(capture);
    }

    const label =
      (capture.type === "selection-long" || capture.type === "selection-live") ? "Área selecionada" :
      capture.type === "full" ? "Página inteira" :
      "Área visível";

    meta.textContent =
      `${label} • ${canvas.width} × ${canvas.height}px • ${capture.title || ""}`;

    loading.hidden = true;
    stage.hidden = false;

    // A captura já fica pronta para Ctrl+V sem exigir clique extra.
    await tryAutoCopy();
  } catch (error) {
    loading.textContent = error?.message || String(error);
    loading.style.color = "#ff8e9a";
  }
}

document.getElementById("copyBtn").addEventListener("click", async () => {
  try {
    await copyImage();
  } catch (e) {
    showToast(e?.message || "Falha ao copiar");
  }
});

document.getElementById("pngBtn").addEventListener("click", async () => {
  try {
    await save("png");
  } catch (e) {
    showToast(e?.message || "Falha ao salvar");
  }
});

document.getElementById("jpgBtn").addEventListener("click", async () => {
  try {
    await save("jpg");
  } catch (e) {
    showToast(e?.message || "Falha ao salvar");
  }
});

document.getElementById("closeBtn").addEventListener("click", () => window.close());

init();
