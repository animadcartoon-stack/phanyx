(() => {
  document.getElementById("__phanyx_print_overlay__")?.remove();
  document.getElementById("__phanyx_print_hint__")?.remove();

  const originalScrollX = window.scrollX;
  const originalScrollY = window.scrollY;
  const sessionId = crypto.randomUUID();

  const getDocSize = () => ({
    width: Math.max(
      document.documentElement.scrollWidth,
      document.body?.scrollWidth || 0,
      window.innerWidth
    ),
    height: Math.max(
      document.documentElement.scrollHeight,
      document.body?.scrollHeight || 0,
      window.innerHeight
    )
  });

  const overlay = document.createElement("div");
  overlay.id = "__phanyx_print_overlay__";

  const size = getDocSize();
  Object.assign(overlay.style, {
    position: "absolute",
    left: "0",
    top: "0",
    width: `${size.width}px`,
    height: `${size.height}px`,
    zIndex: "2147483647",
    cursor: "crosshair",
    background: "rgba(5,10,24,.16)",
    userSelect: "none",
    touchAction: "none"
  });

  const box = document.createElement("div");
  Object.assign(box.style, {
    position: "absolute",
    display: "none",
    border: "2px solid #5f7cff",
    background: "rgba(95,124,255,.10)",
    boxShadow: "0 0 0 99999px rgba(5,10,24,.42)",
    pointerEvents: "none"
  });

  const badge = document.createElement("div");
  Object.assign(badge.style, {
    position: "absolute",
    display: "none",
    padding: "6px 9px",
    borderRadius: "8px",
    color: "#fff",
    background: "rgba(11,16,32,.95)",
    border: "1px solid rgba(255,255,255,.14)",
    font: "600 12px/1 system-ui,sans-serif",
    pointerEvents: "none",
    whiteSpace: "nowrap"
  });

  const hint = document.createElement("div");
  hint.id = "__phanyx_print_hint__";
  hint.innerHTML = `
    <strong style="display:block;margin-bottom:3px">Selecione a área</strong>
    Clique, segure e arraste. Encoste na borda inferior para continuar descendo.
  `;
  Object.assign(hint.style, {
    position: "fixed",
    top: "16px",
    left: "50%",
    transform: "translateX(-50%)",
    zIndex: "2147483647",
    maxWidth: "520px",
    padding: "10px 14px",
    borderRadius: "12px",
    color: "#fff",
    background: "rgba(11,16,32,.95)",
    border: "1px solid rgba(255,255,255,.14)",
    font: "12px/1.35 system-ui,sans-serif",
    boxShadow: "0 10px 28px rgba(0,0,0,.28)",
    pointerEvents: "none",
    textAlign: "center"
  });

  overlay.append(box, badge);
  document.documentElement.append(overlay, hint);

  let dragging = false;
  let pointerId = null;
  let raf = 0;

  let startDocX = 0;
  let startDocY = 0;
  let currentDocX = 0;
  let currentDocY = 0;
  let lastClientX = 0;
  let lastClientY = 0;
  let rect = null;

  let captureInProgress = false;
  let initialCapturePromise = null;
  let sessionStarted = false;
  let capturedCount = 0;
  let lastCapturedX = null;
  let lastCapturedY = null;

  const EDGE_X = 60;
  const EDGE_Y = 120;
  const MAX_V_SPEED = 16;
  const MAX_H_SPEED = 12;

  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

  const fixedItems = [...document.querySelectorAll("body *")]
    .filter((el) => {
      const cs = getComputedStyle(el);
      return cs.position === "fixed" || cs.position === "sticky";
    })
    .map((el) => ({
      el,
      visibility: el.style.visibility,
      transition: el.style.transition
    }));

  function setFixedHidden(hidden) {
    for (const item of fixedItems) {
      if (hidden) {
        item.el.style.transition = "none";
        item.el.style.visibility = "hidden";
      } else {
        item.el.style.visibility = item.visibility;
        item.el.style.transition = item.transition;
      }
    }
  }

  function clientToDocument(x, y) {
    const doc = getDocSize();
    return {
      x: clamp(window.scrollX + x, 0, doc.width),
      y: clamp(window.scrollY + y, 0, doc.height)
    };
  }

  function renderSelection() {
    const p = clientToDocument(lastClientX, lastClientY);
    currentDocX = p.x;
    currentDocY = p.y;

    const left = Math.min(startDocX, currentDocX);
    const top = Math.min(startDocY, currentDocY);
    const width = Math.abs(currentDocX - startDocX);
    const height = Math.abs(currentDocY - startDocY);

    rect = { left, top, width, height };

    box.style.display = "block";
    box.style.left = `${left}px`;
    box.style.top = `${top}px`;
    box.style.width = `${width}px`;
    box.style.height = `${height}px`;

    const doc = getDocSize();
    badge.textContent = `${Math.round(width)} × ${Math.round(height)} px`;
    badge.style.display = "block";
    badge.style.left = `${clamp(currentDocX + 10, 4, Math.max(4, doc.width - 145))}px`;
    badge.style.top = `${clamp(currentDocY + 10, 4, Math.max(4, doc.height - 35))}px`;
  }

  function speedNearEdge(pos, viewport, edge, maxSpeed) {
    if (pos >= viewport - edge) {
      const penetration = clamp((pos - (viewport - edge)) / edge, 0, 1);
      return Math.max(4, Math.round(maxSpeed * penetration));
    }

    if (pos <= edge) {
      const penetration = clamp((edge - pos) / edge, 0, 1);
      return -Math.max(4, Math.round(maxSpeed * penetration));
    }

    return 0;
  }

  function waitFrames(count = 2) {
    return new Promise((resolve) => {
      const step = () => {
        if (--count <= 0) resolve();
        else requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }

  async function startSession() {
    if (sessionStarted) return;
    const response = await chrome.runtime.sendMessage({
      type: "PHANYX_SELECTION_SESSION_START",
      sessionId
    });
    if (!response?.ok) {
      throw new Error(response?.error || "Não foi possível iniciar a captura.");
    }
    sessionStarted = true;
  }

  async function captureCurrentFrame({ force = false } = {}) {
    if (captureInProgress) return;
    captureInProgress = true;

    const hideFixed = capturedCount > 0;

    try {
      await startSession();

      overlay.style.visibility = "hidden";
      hint.style.visibility = "hidden";
      if (hideFixed) setFixedHidden(true);

      await waitFrames(2);

      const response = await chrome.runtime.sendMessage({
        type: "PHANYX_SELECTION_SESSION_CAPTURE",
        sessionId,
        force
      });

      if (!response?.ok) {
        throw new Error(response?.error || "Falha ao guardar trecho da seleção.");
      }

      if (Number.isFinite(response.scrollX)) lastCapturedX = response.scrollX;
      if (Number.isFinite(response.scrollY)) lastCapturedY = response.scrollY;
      if (response.added) capturedCount += 1;
    } finally {
      if (hideFixed) setFixedHidden(false);
      overlay.style.visibility = "visible";
      hint.style.visibility = "visible";
      captureInProgress = false;
    }
  }

  function shouldCaptureAnotherFrame() {
    if (lastCapturedX === null || lastCapturedY === null) return false;

    const dx = Math.abs(window.scrollX - lastCapturedX);
    const dy = Math.abs(window.scrollY - lastCapturedY);

    return (
      dx >= window.innerWidth * 0.65 ||
      dy >= window.innerHeight * 0.62
    );
  }

  function scrollLoop() {
    if (!dragging) return;

    if (!captureInProgress) {
      const sx = speedNearEdge(lastClientX, window.innerWidth, EDGE_X, MAX_H_SPEED);
      const sy = speedNearEdge(lastClientY, window.innerHeight, EDGE_Y, MAX_V_SPEED);

      if (sx || sy) {
        const beforeX = window.scrollX;
        const beforeY = window.scrollY;

        window.scrollBy({
          left: sx,
          top: sy,
          behavior: "instant"
        });

        if (window.scrollX !== beforeX || window.scrollY !== beforeY) {
          renderSelection();

          if (shouldCaptureAnotherFrame()) {
            captureCurrentFrame().catch((error) => {
              console.error("PHANYX Print:", error);
            });
          }
        }
      }
    }

    raf = requestAnimationFrame(scrollLoop);
  }

  function stopLoop() {
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
  }

  function cleanup() {
    stopLoop();
    window.removeEventListener("keydown", onKeyDown, true);
    window.removeEventListener("scroll", onScroll, true);
    window.removeEventListener("wheel", onWheel, { capture: true });
    setFixedHidden(false);
    overlay.remove();
    hint.remove();
  }

  async function cancelSession() {
    try {
      await chrome.runtime.sendMessage({
        type: "PHANYX_SELECTION_SESSION_CANCEL",
        sessionId
      });
    } catch {}
  }

  function onScroll() {
    if (dragging) renderSelection();
  }

  function onWheel(event) {
    if (dragging) {
      event.preventDefault();
    }
  }

  async function onKeyDown(event) {
    if (event.key !== "Escape") return;

    event.preventDefault();
    event.stopPropagation();
    dragging = false;
    cleanup();
    await cancelSession();
    window.scrollTo(originalScrollX, originalScrollY);
  }

  overlay.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;

    dragging = true;
    pointerId = event.pointerId;
    lastClientX = event.clientX;
    lastClientY = event.clientY;

    const p = clientToDocument(event.clientX, event.clientY);
    startDocX = p.x;
    startDocY = p.y;
    currentDocX = p.x;
    currentDocY = p.y;

    hint.innerHTML = `
      <strong style="display:block;margin-bottom:3px">Continue segurando o mouse</strong>
      A captura está sendo preparada durante o próprio arraste.
    `;

    try {
      overlay.setPointerCapture(pointerId);
    } catch {}

    renderSelection();

    initialCapturePromise = captureCurrentFrame({ force: true }).catch((error) => {
      console.error("PHANYX Print:", error);
    });

    raf = requestAnimationFrame(scrollLoop);
  });

  overlay.addEventListener("pointermove", (event) => {
    if (!dragging) return;

    lastClientX = clamp(event.clientX, 0, window.innerWidth);
    lastClientY = clamp(event.clientY, 0, window.innerHeight);
    renderSelection();
  });

  overlay.addEventListener("pointerup", async (event) => {
    if (!dragging) return;

    lastClientX = clamp(event.clientX, 0, window.innerWidth);
    lastClientY = clamp(event.clientY, 0, window.innerHeight);
    renderSelection();

    dragging = false;
    stopLoop();

    try {
      if (pointerId !== null && overlay.hasPointerCapture(pointerId)) {
        overlay.releasePointerCapture(pointerId);
      }
    } catch {}

    const finalRect = rect;

    if (!finalRect || finalRect.width < 4 || finalRect.height < 4) {
      box.style.display = "none";
      badge.style.display = "none";
      hint.innerHTML = `
        <strong style="display:block;margin-bottom:3px">Seleção muito pequena</strong>
        Clique e arraste novamente. Pressione Esc para cancelar.
      `;
      await cancelSession();
      return;
    }

    hint.innerHTML = `
      <strong style="display:block;margin-bottom:3px">Finalizando captura…</strong>
      Só estamos montando a área selecionada.
    `;

    try {
      if (initialCapturePromise) {
        await initialCapturePromise;
      }

      await captureCurrentFrame({ force: true });

      overlay.style.visibility = "hidden";
      hint.style.visibility = "hidden";
      await waitFrames(1);

      const response = await chrome.runtime.sendMessage({
        type: "PHANYX_SELECTION_SESSION_FINISH",
        sessionId,
        rect: finalRect
      });

      if (!response?.ok) {
        throw new Error(response?.error || "Falha ao finalizar a seleção.");
      }
    } catch (error) {
      console.error("PHANYX Print:", error);
      await cancelSession();
    } finally {
      cleanup();
      window.scrollTo(originalScrollX, originalScrollY);
    }
  });

  window.addEventListener("keydown", onKeyDown, true);
  window.addEventListener("scroll", onScroll, true);
  window.addEventListener("wheel", onWheel, { passive: false, capture: true });
})();
